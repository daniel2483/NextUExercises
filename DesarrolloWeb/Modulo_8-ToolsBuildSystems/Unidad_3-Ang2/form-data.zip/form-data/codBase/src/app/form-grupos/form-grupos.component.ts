import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'form-grupos',
  templateUrl: './form-grupos.component.html',
  styleUrls: ['./form-grupos.component.css']
})
export class FormGruposComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
