import { Component } from '@angular/core';
import { FormUsuariosComponent } from './form-usuarios/form-usuarios.component';
import { FormGruposComponent } from './form-grupos/form-grupos.component';
import { AnimacionesComponent } from './animaciones/animaciones.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
}
