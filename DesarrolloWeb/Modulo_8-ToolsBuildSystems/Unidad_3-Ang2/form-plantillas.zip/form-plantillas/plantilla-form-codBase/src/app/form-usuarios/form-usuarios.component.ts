import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'form-usuarios',
  templateUrl: './form-usuarios.component.html',
  styleUrls: ['./form-usuarios.component.css']
})
export class FormUsuariosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
