import { Component } from '@angular/core';
import { FormUsuariosComponent } from './form-usuarios/form-usuarios.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
}
